use super::*;
use crate::decay::observation::ObservationError;
use crate::search::{SearchError, SearchQuery};
use crate::storage::control::ExposureScope;

fn setup() -> (Fixture, Data, Arc<FixedClock>, MemoryId) {
    let root = tempfile::tempdir().unwrap();
    let d = fixture(root.path());
    let clock = Arc::new(FixedClock(AtomicUsize::new(0)));
    let mut session = open(&d, clock.clone());
    let intent = session.capture_insert(scope(&d), &input(&d)).unwrap();
    let receipt = session
        .insert_prepared(&ctx(&session, &d, "create"), &intent, &generated())
        .unwrap();
    let id = inserted(&receipt);
    (
        Fixture::from_open_engine(root, session.engine),
        d,
        clock,
        id,
    )
}
fn observation(error: SearchError) -> ObservationError {
    match error {
        SearchError::Observation(error) => error,
        other => panic!("lost observation outcome: {other:?}"),
    }
}
fn scope_for(d: &Data) -> ExposureScope {
    ExposureScope {
        namespace: "native".into(),
        source: Some(d.parent),
    }
}
fn event_count(f: &Fixture, id: MemoryId) -> usize {
    f.record(id).unwrap().access_history.len()
}

#[tokio::test(flavor = "multi_thread", worker_threads = 2)]
async fn native_exposure_query_deduplicates_returned_ids_preserves_anchor_and_reopens() {
    let (f, d, clock, id) = setup();
    let owner = completion(&f);
    owner.rebuild_all().await.unwrap();
    let (api, bridge, engine) = readers_with_exposure(&f, clock.clone(), true);
    let before = f.record(id).unwrap();
    let source = f.record(d.parent).unwrap().encode().unwrap();
    let calls = clock.0.load(Ordering::SeqCst);
    let receipts = engine
        .record_exposures_at_with_work(
            &[
                (id, crate::model::AccessKind::AssociativeRetrieval),
                (id, crate::model::AccessKind::DirectRetrieval),
                (id, crate::model::AccessKind::AssociativeRetrieval),
            ],
            scope_for(&d),
            123_456,
            None,
        )
        .await
        .unwrap();
    assert_eq!(receipts.len(), 1);
    assert_eq!(
        clock.0.load(Ordering::SeqCst),
        calls,
        "sampled time must not consult caller clock again"
    );
    let after = f.record(id).unwrap();
    let old = &before.schema.as_ref().unwrap().lifecycle;
    let new = &after.schema.as_ref().unwrap().lifecycle;
    assert_eq!(new.retrieved_at, Some(123_456));
    assert_eq!(new.decay_anchor_at, old.decay_anchor_at);
    assert_eq!(new.reinforced_at, old.reinforced_at);
    assert_eq!(new.observed_at, old.observed_at);
    assert_eq!(new.phase_changed_at, old.phase_changed_at);
    assert_eq!(
        (after.stability, after.phase, after.is_permastore),
        (before.stability, before.phase, before.is_permastore)
    );
    assert_eq!(after.access_history.len(), before.access_history.len() + 1);
    assert_eq!(
        after.access_history.last().unwrap().kind,
        crate::model::AccessKind::DirectRetrieval
    );
    assert_eq!(
        f.record(d.parent).unwrap().encode().unwrap(),
        source,
        "scope source is not an exposed result"
    );
    let query: SearchQuery = serde_json::from_value(
        json!({"namespace":"native","queryMode":"metadata_only","recordAccess":false}),
    )
    .unwrap();
    let stable = bytes(&d.path);
    for _ in 0..2 {
        engine.search(query.clone()).await.unwrap();
    }
    assert_eq!(bytes(&d.path), stable);
    let mut query = query;
    query.record_access = true;
    let counts = [event_count(&f, id), event_count(&f, d.parent)];
    let calls = clock.0.load(Ordering::SeqCst);
    let result = engine.search(query).await.unwrap();
    assert_eq!(result.results.len(), 2);
    assert_eq!(clock.0.load(Ordering::SeqCst), calls + 1);
    assert_eq!(
        [event_count(&f, id), event_count(&f, d.parent)],
        [counts[0] + 1, counts[1] + 1]
    );
    let state = f
        .storage
        .read()
        .unwrap()
        .meta_store()
        .publication_state()
        .unwrap();
    assert!(state.matches_canonical(), "{state:?}");
    drop((api, bridge, engine, owner));
    let root = f.close();
    let reopened = open(&d, clock);
    assert_eq!(
        reopened
            .engine
            .get_record(id)
            .unwrap()
            .unwrap()
            .access_history
            .len(),
        counts[0] + 1
    );
    drop((reopened, root));
}

#[tokio::test(flavor = "multi_thread", worker_threads = 2)]
async fn native_exposure_http_mcp_get_similar_true_and_false_use_real_observer() {
    let (f, d, clock, id) = setup();
    completion(&f).rebuild_all().await.unwrap();
    let (api, bridge, engine) = readers_with_exposure(&f, clock.clone(), true);
    let stable = bytes(&d.path);
    for access in [false, true] {
        let count = event_count(&f, id);
        let calls = clock.0.load(Ordering::SeqCst);
        let (status, body) = http(
            &api,
            "GET",
            &format!("/memories/{id}?recordAccess={access}"),
            Value::Null,
        )
        .await;
        assert!(status.is_success(), "{body}");
        assert_eq!(event_count(&f, id), count + usize::from(access));
        assert_eq!(clock.0.load(Ordering::SeqCst), calls + 1);
        let count = event_count(&f, id);
        let calls = clock.0.load(Ordering::SeqCst);
        mcp(
            &bridge,
            "get_memory",
            json!({"id":id,"recordAccess":access}),
        )
        .await;
        assert_eq!(event_count(&f, id), count + usize::from(access));
        assert_eq!(clock.0.load(Ordering::SeqCst), calls + 1);
        let source = event_count(&f, id);
        let target = event_count(&f, d.parent);
        let (status, body) = http(
            &api,
            "POST",
            &format!("/similar/{id}"),
            json!({"recordAccess":access}),
        )
        .await;
        assert!(status.is_success(), "{body}");
        assert!(!body["hits"].as_array().unwrap().is_empty());
        assert_eq!(event_count(&f, id), source);
        assert_eq!(event_count(&f, d.parent), target + usize::from(access));
        let target = event_count(&f, d.parent);
        let body = mcp(
            &bridge,
            "find_similar_memories",
            json!({"id":id,"recordAccess":access}),
        )
        .await;
        assert!(!body["memories"].as_array().unwrap().is_empty());
        assert_eq!(event_count(&f, id), source);
        assert_eq!(event_count(&f, d.parent), target + usize::from(access));
        if !access {
            assert_eq!(bytes(&d.path), stable);
        }
    }
    assert!(
        f.storage
            .read()
            .unwrap()
            .meta_store()
            .publication_state()
            .unwrap()
            .matches_canonical()
    );
    drop((api, bridge, engine));
}

#[tokio::test(flavor = "multi_thread", worker_threads = 2)]
async fn native_exposure_partial_publication_keeps_receipt_and_repairs_without_reobservation() {
    let (f, d, clock, id) = setup();
    let owner = completion(&f);
    owner.rebuild_all().await.unwrap();
    let (_api, _bridge, engine) = readers_with_exposure(&f, clock, true);
    *f.vector_index.write().await = crate::search::FlatVectorIndex::new(8);
    let before = event_count(&f, id);
    let error = observation(
        engine
            .record_exposures_at_with_work(
                &[(id, crate::model::AccessKind::DirectRetrieval)],
                scope_for(&d),
                5000,
                None,
            )
            .await
            .unwrap_err(),
    );
    assert_eq!(error.commit_state, "committed");
    assert_eq!(error.receipts.len(), 1);
    assert!(!error.ready);
    assert!(error.unknown_operation_id.is_none());
    assert_eq!(event_count(&f, id), before + 1);
    assert!(
        !f.storage
            .read()
            .unwrap()
            .meta_store()
            .publication_state()
            .unwrap()
            .matches_canonical()
    );
    *f.vector_index.write().await = crate::search::FlatVectorIndex::new(4);
    owner.complete().await.unwrap();
    assert_eq!(event_count(&f, id), before + 1);
    assert!(
        f.storage
            .read()
            .unwrap()
            .meta_store()
            .publication_state()
            .unwrap()
            .matches_canonical()
    );
}

#[tokio::test(flavor = "multi_thread", worker_threads = 2)]
async fn native_exposure_unknown_commit_keeps_operation_and_requires_reopen() {
    let (f, d, clock, id) = setup();
    let owner = completion(&f);
    owner.rebuild_all().await.unwrap();
    let (api, bridge, engine) = readers_with_exposure(&f, clock.clone(), true);
    let before = event_count(&f, id);
    f.storage
        .read()
        .unwrap()
        .meta_store()
        .observation_fault
        .store(3, Ordering::SeqCst);
    let error = observation(
        engine
            .record_exposures_at_with_work(
                &[(id, crate::model::AccessKind::DirectRetrieval)],
                scope_for(&d),
                5000,
                None,
            )
            .await
            .unwrap_err(),
    );
    assert_eq!(error.commit_state, "unknown");
    assert!(!error.ready);
    assert!(error.receipts.is_empty());
    let operation = error.unknown_operation_id.unwrap();
    assert!(owner.complete().await.is_err());
    drop((api, bridge, engine, owner));
    let root = f.close();
    let reopened = open(&d, clock);
    assert_eq!(
        reopened
            .engine
            .get_record(id)
            .unwrap()
            .unwrap()
            .access_history
            .len(),
        before + 1
    );
    assert!(
        reopened
            .metadata()
            .lookup_operation(
                reopened.metadata().control_state().unwrap().store_id,
                MutationScope::Namespace(d.ns),
                operation
            )
            .unwrap()
            .is_some()
    );
    drop((reopened, root));
}
