//! Test-only probe compiled against unchanged PR126 runtime before origin edits.
use super::*;
use crate::test_support::Fixture;
use serde_json::json;

#[tokio::test(flavor = "multi_thread", worker_threads = 2)]
async fn original_api_before_authors_genuine_old_two_fixture() {
    let root = std::path::PathBuf::from(
        std::env::var("RECALLD_ORIGIN_BEFORE_ROOT").expect("explicit isolated output"),
    );
    assert!(
        !root.exists(),
        "never overwrite an earlier source/binary fixture"
    );
    std::fs::create_dir_all(&root).unwrap();
    let d = fixture(&root);
    let clock = Arc::new(FixedClock(AtomicUsize::new(0)));
    let session = open(&d, clock.clone());
    let mut feedback_ctx = ctx(&session, &d, "genuine-old2-feedback");
    feedback_ctx.expected_generation = Some(
        session
            .metadata()
            .control_state()
            .unwrap()
            .committed_generation,
    );
    let f = Fixture::from_open_engine(tempfile::tempdir().unwrap(), session.engine);
    let owner = readers::completion(&f);
    owner.rebuild_all().await.unwrap();
    let feedback = owner
        .feedback_native_with_work(
            feedback_ctx.clone(),
            d.parent,
            3,
            None,
            NativePolicyInputs::default(),
            clock.clone(),
            None,
        )
        .await
        .unwrap();
    let mut one = feedback_ctx.clone();
    one.contract_version = 1;
    one.idempotency_key = Some("before-api1".into());
    one.expected_generation = None;
    let before = f.record(d.parent).unwrap().encode().unwrap();
    let calls = clock.0.load(Ordering::SeqCst);
    assert!(matches!(
        owner
            .feedback_native_with_work(
                one,
                d.parent,
                3,
                None,
                NativePolicyInputs::default(),
                clock.clone(),
                None
            )
            .await,
        Err(StorageError::InvalidMutationContext(_))
    ));
    assert_eq!(clock.0.load(Ordering::SeqCst), calls);
    assert_eq!(f.record(d.parent).unwrap().encode().unwrap(), before);
    let mut forget_ctx = feedback_ctx.clone();
    forget_ctx.idempotency_key = Some("genuine-old2-forget".into());
    forget_ctx.expected_generation = Some(feedback.committed_generation);
    let forgotten = owner
        .forget_native_with_work(
            forget_ctx,
            d.parent,
            None,
            NativePolicyInputs::default(),
            clock.clone(),
            None,
        )
        .await
        .unwrap();
    let receipts = {
        let storage = f.storage.read().unwrap();
        let read = storage.meta_store().db.begin_read().unwrap();
        let table = read.open_table(control::RECEIPTS).unwrap();
        table
            .iter()
            .unwrap()
            .map(|r| {
                let (k, v) = r.unwrap();
                (k.value().to_vec(), v.value().to_vec())
            })
            .collect::<Vec<_>>()
    };
    std::fs::write(root.join("expected.json"),serde_json::to_vec_pretty(&json!({"namespaceId":d.ns,"memoryId":d.parent,"storeId":feedback.store_id,"feedbackExpectedGeneration":feedback_ctx.expected_generation,"feedback":feedback,"forget":forgotten,"rawReceipts":receipts,"beforeApi1":"InvalidMutationContext; no bytes/time change"})).unwrap()).unwrap();
    drop(owner);
    let _temp = f.close();
    let files = crate::storage::validation::canonical_files(&d.path).unwrap();
    std::fs::write(
        root.join("inventory.json"),
        serde_json::to_vec_pretty(
            &files
                .iter()
                .map(|p| p.strip_prefix(&d.path).unwrap().to_str().unwrap())
                .collect::<Vec<_>>(),
        )
        .unwrap(),
    )
    .unwrap();
    println!(
        "genuine old2 fixture authored; API1 rejected before clock/bytes; {} canonical files",
        files.len()
    );
}
