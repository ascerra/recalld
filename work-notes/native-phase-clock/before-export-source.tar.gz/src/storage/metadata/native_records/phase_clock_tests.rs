//! Real legacy insertion, schema/policy migration and native forget. Raw table
//! access is read-only evidence collection, never fixture construction.
use super::*;
use std::sync::atomic::AtomicI64;

struct RegressedClock {
    time: AtomicI64,
    calls: AtomicUsize,
}
impl Clock for RegressedClock {
    fn now_millis(&self) -> i64 {
        self.calls.fetch_add(1, Ordering::SeqCst);
        self.time.load(Ordering::SeqCst)
    }
}

fn receipts(session: &NativeLifecycleSession) -> std::collections::BTreeMap<Vec<u8>, Vec<u8>> {
    session
        .metadata()
        .db
        .begin_read()
        .unwrap()
        .open_table(control::RECEIPTS)
        .unwrap()
        .iter()
        .unwrap()
        .map(|row| {
            let (key, value) = row.unwrap();
            (key.value().to_vec(), value.value().to_vec())
        })
        .collect()
}

#[test]
fn actual_migration_native_forget_preserves_phase_marker_under_regressed_clock() {
    let root = tempfile::tempdir().unwrap();
    let d = fixture(root.path());
    let clock = Arc::new(RegressedClock {
        time: AtomicI64::new(500),
        calls: AtomicUsize::new(0),
    });
    let mut session =
        NativeLifecycleSession::open(&d.path, NativePolicyInputs::default(), clock.clone())
            .unwrap();
    let before = session.engine.get_record(d.parent).unwrap().unwrap();
    let old = before.schema.as_ref().unwrap().lifecycle.clone();
    assert_eq!(before.created_at, 1000);
    assert_eq!(old.lifecycle_updated_at, 1000);
    assert_eq!(old.phase_changed_at, 2000);
    assert_eq!(old.timestamp_origin, TimestampOrigin::LegacyInferred);
    assert_eq!(old.retrieved_at, None);
    assert_eq!(old.reinforced_at, None);
    let historical = receipts(&session);
    let publication = crate::storage::canonical_schema::read_state(
        &session.metadata().db.begin_read().unwrap(),
        &session.metadata().control_state().unwrap(),
    )
    .unwrap();
    let intent = session.capture_tombstone(d.parent, None).unwrap();
    let key = ctx(&session, &d, "regressed-native-forget");
    let receipt = session.tombstone(&key, &intent).unwrap();
    assert_eq!(clock.calls.load(Ordering::SeqCst), 1);
    let after = session.engine.get_record(d.parent).unwrap().unwrap();
    let next = &after.schema.as_ref().unwrap().lifecycle;
    assert_eq!(after.phase, DecayPhase::Tombstone);
    assert!(after.summary.is_empty());
    assert_eq!(after.text_length, 0);
    assert!(after.schema.as_ref().unwrap().vector.is_none());
    assert_eq!(next.lifecycle_updated_at, 1000); // A3 effective_now rule.
    assert_eq!(next.decay_anchor_at, old.decay_anchor_at);
    assert_eq!(next.observed_at, old.observed_at);
    assert_eq!(next.retrieved_at, old.retrieved_at);
    assert_eq!(next.reinforced_at, old.reinforced_at);
    assert_eq!(next.timestamp_origin, old.timestamp_origin);
    assert_eq!(after.last_accessed_at, before.last_accessed_at);
    assert_eq!(after.access_history, before.access_history);
    assert_eq!(
        next.record_generation,
        old.record_generation.next().unwrap()
    );
    assert_eq!(
        crate::storage::canonical_schema::read_state(
            &session.metadata().db.begin_read().unwrap(),
            &session.metadata().control_state().unwrap(),
        )
        .unwrap(),
        publication
    );
    for (key, value) in &historical {
        assert_eq!(receipts(&session).get(key), Some(value));
    }
    clock.time.store(99, Ordering::SeqCst);
    let replay = session.tombstone(&key, &intent).unwrap();
    assert!(replay.replayed);
    assert_eq!(replay.operation_id, receipt.operation_id);
    assert_eq!(replay.outcome, receipt.outcome);
    assert_eq!(clock.calls.load(Ordering::SeqCst), 1);
    drop(session);
    inspect_schema(&d.path).unwrap();
    let mut reopened =
        NativeLifecycleSession::open(&d.path, NativePolicyInputs::default(), clock.clone())
            .unwrap();
    let retained = reopened.engine.get_record(d.parent).unwrap().unwrap();
    assert_eq!(retained.schema, after.schema);
    assert!(reopened.tombstone(&key, &intent).unwrap().replayed);
    assert_eq!(clock.calls.load(Ordering::SeqCst), 1);
    assert!(RedbStorageEngine::open(&d.path).is_err());
    drop(reopened);
    // Used only by the recorded BEFORE invocation to preserve a real old-format
    // fixture through the production exporter, before changing its writer.
    if let Ok(path) = std::env::var("RECALLD_TEST_PHASE_CLOCK_EXPORT") {
        crate::storage::logical_export::export_store(&d.path, Path::new(&path)).unwrap();
    }

    // Unknown historical phase time remains the immutable migration marker.
    // A later real phase change may clamp that marker, but cannot move it back.
    assert!(
        next.phase_changed_at >= old.phase_changed_at,
        "phase marker regressed after actual migration/forget/reopen: {} -> {}",
        old.phase_changed_at,
        next.phase_changed_at
    );
}
