use super::*;
use crate::storage::native_maintenance::{NativeDecayResult, NativeDecaySkip};
use std::sync::atomic::AtomicI64;
const DAY: i64 = 86_400_000;
struct Clock {
    now: AtomicI64,
    calls: AtomicUsize,
}
impl Clock {
    fn new(now: i64) -> Self {
        Self {
            now: AtomicI64::new(now),
            calls: AtomicUsize::new(0),
        }
    }
    fn set(&self, now: i64) {
        self.now.store(now, Ordering::SeqCst);
    }
}
impl crate::time::Clock for Clock {
    fn now_millis(&self) -> i64 {
        self.calls.fetch_add(1, Ordering::SeqCst);
        self.now.load(Ordering::SeqCst)
    }
}
fn session(d: &Data, c: Arc<Clock>) -> NativeLifecycleSession {
    NativeLifecycleSession::open(&d.path, NativePolicyInputs::default(), c).unwrap()
}
fn create(
    s: &mut NativeLifecycleSession,
    d: &Data,
    key: &str,
    mut original: NativeInsert,
) -> MemoryId {
    original.memory.initial_stability = Some(1.);
    let intent = s.capture_insert(scope(d), &original).unwrap();
    inserted(
        &s.insert_prepared(&ctx(s, d, key), &intent, &generated())
            .unwrap(),
    )
}
fn committed(r: NativeDecayResult) -> WriteReceipt {
    match r {
        NativeDecayResult::Committed(r) => r,
        other => panic!("expected commit, got {other:?}"),
    }
}
fn record(s: &NativeLifecycleSession, id: MemoryId) -> DiskRecord {
    s.engine.get_record(id).unwrap().unwrap()
}
fn immutable_lifecycle(a: &DiskRecord, b: &DiskRecord) {
    assert_eq!(a.stability, b.stability);
    assert_eq!(a.difficulty, b.difficulty);
    assert_eq!(a.last_accessed_at, b.last_accessed_at);
    assert_eq!(a.access_history, b.access_history);
    assert_eq!(a.is_permastore, b.is_permastore);
    let x = &a.schema.as_ref().unwrap().lifecycle;
    let y = &b.schema.as_ref().unwrap().lifecycle;
    assert_eq!(x.decay_anchor_at, y.decay_anchor_at);
    assert_eq!(x.observed_at, y.observed_at);
    assert_eq!(x.retrieved_at, y.retrieved_at);
    assert_eq!(x.reinforced_at, y.reinforced_at);
    assert_eq!(x.timestamp_origin, y.timestamp_origin);
}
#[test]
fn native_maintenance_one_phase_retains_ghost_vector_then_deletes_with_witness_peers_and_replay() {
    let root = tempfile::tempdir().unwrap();
    let d = fixture(root.path());
    let c = Arc::new(Clock::new(3000));
    let mut s = session(&d, c.clone());
    let id = create(&mut s, &d, "create", input(&d));
    let exposure = s
        .capture_exposure(
            scope(&d),
            &[(id, crate::model::AccessKind::DirectRetrieval)],
        )
        .unwrap();
    s.record_exposure(&ctx(&s, &d, "exposure"), &exposure)
        .unwrap();
    let original = record(&s, id);
    let vector = original.schema.as_ref().unwrap().vector.clone();
    let parent = record(&s, d.parent);
    c.set(10_000 * DAY);
    let first = committed(s.maintain(&ctx(&s, &d, "summary"), id).unwrap());
    let summary = record(&s, id);
    assert_eq!(summary.phase, DecayPhase::Summary);
    assert_eq!(summary.summary, original.summary);
    assert_eq!(
        summary.schema.as_ref().unwrap().labels,
        original.schema.as_ref().unwrap().labels
    );
    assert_eq!(summary.text_length, 0);
    immutable_lifecycle(&original, &summary);
    drop(s);
    let mut s = session(&d, c.clone());
    let second = committed(s.maintain(&ctx(&s, &d, "ghost"), id).unwrap());
    let ghost = record(&s, id);
    assert_eq!(ghost.phase, DecayPhase::Ghost);
    assert!(ghost.summary.is_empty());
    assert!(ghost.tags.is_empty());
    assert!(ghost.schema.as_ref().unwrap().labels.is_empty());
    assert_eq!(ghost.schema.as_ref().unwrap().vector, vector);
    immutable_lifecycle(&original, &ghost);
    assert!(
        !s.engine
            .get_vector(d.ns, ghost.vector_slot)
            .unwrap()
            .unwrap()
            .is_empty()
    );
    drop(s);
    let mut s = session(&d, c.clone());
    let key = ctx(&s, &d, "delete");
    let third = committed(s.maintain(&key, id).unwrap());
    let MutationOutcome::NativeMemoryHardDeleted { transition } = &third.outcome else {
        panic!("wrong outcome")
    };
    assert_eq!(transition.deletion.history, original.access_history);
    assert_eq!(transition.peers.len(), 1);
    assert!(s.engine.get_record(id).unwrap().is_none());
    let peer = record(&s, d.parent);
    assert_eq!(peer.edge_count, 0);
    assert_eq!(
        peer.schema.as_ref().unwrap().lifecycle.record_generation,
        parent
            .schema
            .as_ref()
            .unwrap()
            .lifecycle
            .record_generation
            .next()
            .unwrap()
    );
    assert_eq!(
        third.committed_generation,
        second.committed_generation.next().unwrap()
    );
    assert_eq!(
        second.committed_generation,
        first.committed_generation.next().unwrap()
    );
    let raw = serde_json::to_string(&third).unwrap();
    assert!(!raw.contains(&original.summary));
    assert!(!raw.contains("native full text"));
    assert!(!raw.contains("Topic / exact"));
    let read = s.metadata().db.begin_read().unwrap();
    let ledger = removal_ledger::read_export(&read, Some(&s.metadata().control_state().unwrap()))
        .unwrap()
        .unwrap();
    assert!(
        ledger
            .entries
            .iter()
            .any(|e| e.memory_uuid == id.into_inner()
                && e.terminal_kind == Some(removal_ledger::TerminalKind::HardDelete)
                && e.removed_fields_mask == removal_ledger::ALL
                && e.operation_id == third.operation_id)
    );
    drop(read);
    let calls = c.calls.load(Ordering::SeqCst);
    let replay = committed(s.maintain(&key, id).unwrap());
    assert!(replay.replayed);
    assert_eq!(replay.operation_id, third.operation_id);
    assert_eq!(c.calls.load(Ordering::SeqCst), calls);
    let mut new = input(&d);
    new.memory.parent_id = None;
    let replacement = create(&mut s, &d, "replacement", new);
    let before = record(&s, replacement);
    assert_eq!(before.vector_slot, original.vector_slot);
    assert!(committed(s.maintain(&key, id).unwrap()).replayed);
    assert_eq!(
        record(&s, replacement).encode().unwrap(),
        before.encode().unwrap()
    );
    assert!(
        !s.engine
            .get_vector(d.ns, before.vector_slot)
            .unwrap()
            .unwrap()
            .is_empty()
    );
    let mut reuse = input(&d);
    reuse.memory.id = Some(id);
    let intent = s.capture_insert(scope(&d), &reuse).unwrap();
    assert!(
        s.insert_prepared(&ctx(&s, &d, "reuse"), &intent, &generated())
            .is_err()
    );
    drop(s);
    inspect_schema(&d.path).unwrap();
    let _reopened = session(&d, c);
}

#[test]
fn native_maintenance_rechecks_new_canonical_edges_with_original_clock_for_phase_and_strength_only()
{
    for days in [2.0, 4.5] {
        let root = tempfile::tempdir().unwrap();
        let d = fixture(root.path());
        let c = Arc::new(Clock::new(3000));
        let mut s = session(&d, c.clone());
        let mut target = input(&d);
        target.memory.parent_id = None;
        let id = create(&mut s, &d, "target", target);
        let now = 3000 + (days * DAY as f64) as i64;
        c.set(now);
        let intent = s.capture_decay(id, d.ns).unwrap();
        let before = record(&s, id);
        let ns = s.engine.get_namespace(d.ns).unwrap().unwrap();
        let policy = NativePolicyInputs::default().resolve(&ns).unwrap();
        let raw = crate::decay::lifecycle::project(1., 3000, &policy, now, 0.).unwrap();
        if days == 4.5 {
            assert!(raw.decay_strength < 0.7);
        }
        let mut donor = input(&d);
        donor.memory.parent_id = None;
        donor.memory.supersedes = Some(id);
        donor.memory.created_at = Some(now);
        create(&mut s, &d, "donor", donor);
        assert_eq!(
            record(&s, id)
                .schema
                .as_ref()
                .unwrap()
                .lifecycle
                .record_generation,
            before.schema.as_ref().unwrap().lifecycle.record_generation
        );
        c.set(10_000 * DAY);
        let calls = c.calls.load(Ordering::SeqCst);
        committed(s.apply_decay(&ctx(&s, &d, "maintain"), &intent).unwrap());
        let after = record(&s, id);
        assert_eq!(after.phase, DecayPhase::Full);
        assert_eq!(after.strength, raw.strength);
        assert!(after.decay_strength > raw.decay_strength);
        assert_eq!(
            after
                .schema
                .as_ref()
                .unwrap()
                .lifecycle
                .lifecycle_updated_at,
            now
        );
        assert_eq!(c.calls.load(Ordering::SeqCst), calls);
        immutable_lifecycle(&before, &after);
        drop(s);
        inspect_schema(&d.path).unwrap();
    }
}

#[test]
fn native_maintenance_uses_anchor_and_rejects_stale_feedback_and_global_policy_without_receipts() {
    let root = tempfile::tempdir().unwrap();
    let d = fixture(root.path());
    let c = Arc::new(Clock::new(3000));
    let mut s = session(&d, c.clone());
    let mut original = input(&d);
    original.memory.parent_id = None;
    let id = create(&mut s, &d, "target", original);
    c.set(3000 + DAY);
    let access = s
        .capture_exposure(
            scope(&d),
            &[(id, crate::model::AccessKind::DirectRetrieval)],
        )
        .unwrap();
    s.record_exposure(&ctx(&s, &d, "access"), &access).unwrap();
    let before = record(&s, id);
    assert_eq!(
        before.schema.as_ref().unwrap().lifecycle.decay_anchor_at,
        3000
    );
    assert_eq!(before.last_accessed_at, 3000 + DAY);
    c.set(3000 + DAY * 9 / 2);
    committed(s.maintain(&ctx(&s, &d, "phase"), id).unwrap());
    assert_eq!(record(&s, id).phase, DecayPhase::Summary);
    let intent = s.capture_decay(id, d.ns).unwrap();
    let feedback = s.capture_feedback(id, None, 3).unwrap();
    s.apply_feedback(&ctx(&s, &d, "feedback"), &feedback)
        .unwrap();
    let state = s.metadata().control_state().unwrap();
    let before = record(&s, id).encode().unwrap();
    assert!(matches!(
        s.apply_decay(&ctx(&s, &d, "stale"), &intent).unwrap(),
        NativeDecayResult::Skipped(NativeDecaySkip::Stale)
    ));
    assert_eq!(s.metadata().control_state().unwrap(), state);
    assert_eq!(record(&s, id).encode().unwrap(), before);
    let intent = s.capture_decay(id, d.ns).unwrap();
    s.policy.multiplier = 2.;
    assert!(matches!(
        s.apply_decay(&ctx(&s, &d, "policy"), &intent).unwrap(),
        NativeDecayResult::Skipped(NativeDecaySkip::Stale)
    ));
    assert_eq!(s.metadata().control_state().unwrap(), state);
    s.policy.multiplier = 0.;
    assert!(matches!(
        s.maintain(&ctx(&s, &d, "exempt"), id).unwrap(),
        NativeDecayResult::Skipped(NativeDecaySkip::Exempt)
    ));
    assert_eq!(s.metadata().control_state().unwrap(), state);
    drop(s);
    inspect_schema(&d.path).unwrap();
}
