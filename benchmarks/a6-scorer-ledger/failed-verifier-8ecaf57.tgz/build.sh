set -eu
mkdir -p /tmp/home
cd /work/source
rustc -Vv > /work/output/rustc.txt
uname -a > /work/output/kernel.txt
cat /proc/cpuinfo > /work/output/cpu.txt
cat /proc/meminfo > /work/output/memory.txt
df -T /work > /work/output/filesystem.txt
df -T /tmp > /work/output/storage-filesystem.txt
cat /sys/fs/cgroup/memory.max > /work/output/cgroup-memory.txt
cat /sys/fs/cgroup/cpu.max > /work/output/cgroup-cpu.txt
python3 scripts/test_offline_evaluation.py > /work/output/runner-tests.log 2>&1
cargo fmt --all --check > /work/output/format.log 2>&1
cargo clean -p recalld > /work/output/package-clean.log 2>&1
cargo test --locked --offline --all-features --lib --bins --tests --examples -j1 > /work/output/library-tests.log 2>&1
cargo test --locked --offline --example offline_eval > /work/output/harness-tests.log 2>&1
cargo clippy --locked --offline --all-features --all-targets > /work/output/clippy.log 2>&1
cargo build --locked --offline --release --example offline_eval -j1 > /work/output/build.log 2>&1
python3 scripts/check-evaluation-contract.py --binary /work/target/release/examples/offline_eval --manifest /work/output/manifest.json --output /work/output/manifest-rejections.json > /work/output/manifest-tests.log 2>&1
