import hashlib,json,subprocess,sys
from pathlib import Path
root=Path('/tmp/recalld-owned-freeze-full-ew_ndkx0')
prior=root/'output/manifest.json'; m=json.loads(prior.read_text())
out=root/'public-tail';out.mkdir()
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
for name,want in m['sourceFilesSha256'].items(): assert sha(root/'source'/name)==want,name
(out/'driver.py').write_bytes(Path(__file__).read_bytes())
cmd=m['command'][:-4]
# The previous command ends image,sh,-c,script. Keep identical isolation/source
# mounts and same-source private target; overlay only a separate output folder.
cmd+=['--mount',f'type=bind,src={out},dst=/work/output',m['imageId'],'sh','-c','''set -eu
trap 'cat /sys/fs/cgroup/memory.events > /work/output/memory-events.txt; cat /sys/fs/cgroup/memory.peak > /work/output/memory-peak.txt' EXIT
cargo build --offline --locked --bin recalld -j 1 > /work/output/bin-build.log 2>&1
python3 scripts/public-conformance.py --inside --fixture-version 3 > /work/output/public.log 2>&1
python3 scripts/test_public_conformance.py > /work/output/runner-tests.log 2>&1
''']
manifest={'sourceCommit':m['sourceCommit'],'parentManifestSha256':sha(prior),'sourceFilesSha256':m['sourceFilesSha256'],'command':cmd,'status':'running'}
(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
result=subprocess.run(cmd)
for name,want in m['sourceFilesSha256'].items(): assert sha(root/'source'/name)==want,name
old=json.loads((root/'output/source-binaries.json').read_text())
for name,want in old['sha256'].items(): assert sha(root/name)==want,name
manifest.update(exitCode=result.returncode,status='passed' if result.returncode==0 else 'failed',unchangedPriorBinaries=old['sha256'],publicBinarySha256=sha(root/'target/debug/recalld'),outputsSha256={str(p.relative_to(out)):sha(p) for p in out.rglob('*') if p.is_file() and p.name!='manifest.json'})
(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'root':str(out),'exitCode':result.returncode}),flush=True)
sys.exit(result.returncode)
