//! Additive control/receipt tables for the existing metadata layout.
//!
//! Control schema 1 is NOT canonical/record schema 2. It does not migrate
//! payloads, provide a whole-store read view, or certify derived readiness.
//! Until all writers/effects participate, this counter must not be advertised
//! as a public cursor/barrier generation. Existing metadata writes advance it.

use redb::{
    MultimapTableHandle, ReadTransaction, ReadableTable, ReadableTableMetadata, TableDefinition,
    TableHandle, WriteTransaction,
};
use serde::{Deserialize, Serialize};
use sha2::{Digest, Sha256};
use uuid::Uuid;

use super::error::StorageError;
use crate::model::{MemoryId, NamespaceId};

pub(crate) const CONTROL: TableDefinition<&str, &[u8]> = TableDefinition::new("canonical_control");
pub(crate) const RECEIPTS: TableDefinition<&[u8], &[u8]> =
    TableDefinition::new("mutation_receipts");
pub(crate) const KEYS: TableDefinition<&[u8], &[u8]> = TableDefinition::new("mutation_keys");

/// Final exposure assertion, checked with canonical records in the write transaction.
/// Namespace is the name pinned during selection; a by-ID source must still
/// belong to that same namespace even when it is not itself exposed.
#[derive(Debug, Clone, Serialize)]
pub struct ExposureScope {
    pub namespace: String,
    pub source: Option<crate::model::MemoryId>,
}

// Per-test-thread work counts, not timing or a process-wide instrumentation
// switch. Count receipt decoding as well as full proof entry so a regression
// cannot hide a history scan behind a different validation helper.
#[cfg(test)]
#[derive(Debug, Default, Clone, Copy, PartialEq, Eq)]
pub(crate) struct ValidationWork {
    pub full_validations: usize,
    pub receipt_decodes: usize,
}
#[cfg(test)]
thread_local! {
    static VALIDATION_WORK: std::cell::Cell<ValidationWork> = const {
        std::cell::Cell::new(ValidationWork { full_validations: 0, receipt_decodes: 0 })
    };
}
#[cfg(test)]
pub(crate) fn take_validation_work() -> ValidationWork {
    VALIDATION_WORK.with(|work| work.replace(ValidationWork::default()))
}

/// Canonical decimal-string u63. JSON numbers, signs and leading zeros fail.
#[derive(Debug, Clone, Copy, Default, PartialEq, Eq, PartialOrd, Ord, Serialize, Deserialize)]
#[serde(try_from = "String", into = "String")]
pub struct Generation(u64);

impl Generation {
    pub const MAX: Self = Self(i64::MAX as u64);

    pub fn get(self) -> u64 {
        self.0
    }

    pub(crate) fn next(self) -> Result<Self, StorageError> {
        if self == Self::MAX {
            return Err(StorageError::GenerationExhausted);
        }
        Ok(Self(self.0 + 1))
    }
}

impl TryFrom<String> for Generation {
    type Error = StorageError;
    fn try_from(value: String) -> Result<Self, Self::Error> {
        if value.is_empty()
            || (value.len() > 1 && value.starts_with('0'))
            || !value.bytes().all(|c| c.is_ascii_digit())
        {
            return Err(StorageError::InvalidMutationContext(
                "noncanonical generation".into(),
            ));
        }
        match value.parse::<u64>() {
            Ok(n) if n <= Self::MAX.0 => Ok(Self(n)),
            _ => Err(StorageError::InvalidMutationContext(
                "generation outside u63 range".into(),
            )),
        }
    }
}

impl From<Generation> for String {
    fn from(value: Generation) -> Self {
        value.0.to_string()
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct GenerationRef {
    pub store_id: Uuid,
    pub generation: Generation,
}

/// Validate a generation in its own lineage, including verified restore ancestors.
/// This never infers ancestry from a receipt or compares counters across store IDs.
pub(crate) fn permits_generation_origin(
    read: &ReadTransaction,
    control: &ControlState,
    origin: GenerationRef,
) -> Result<bool, StorageError> {
    super::lineage::permits_origin(read, control, origin)
}

/// Versioned separately from the untouched DiskRecord v1 and payload layout.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "camelCase", deny_unknown_fields)]
pub struct ControlState {
    pub control_schema_version: u32,
    pub store_id: Uuid,
    pub committed_generation: Generation,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub removal_ledger_version: Option<u32>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub restore_lineage_version: Option<u32>,
}

impl ControlState {
    pub fn generation_ref(&self) -> GenerationRef {
        GenerationRef {
            store_id: self.store_id,
            generation: self.committed_generation,
        }
    }

    pub(crate) fn decode(bytes: &[u8]) -> Result<Self, StorageError> {
        let state: Self = decode(bytes)?;
        if !matches!(state.control_schema_version, 1 | 2) || state.store_id.is_nil() {
            return Err(StorageError::InvalidControl(
                "unsupported version or nil store ID".into(),
            ));
        }
        Ok(state)
    }
}

/// Catalog cannot alias namespace 0 or a mutable namespace name.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "camelCase", tag = "kind", content = "namespaceId")]
pub enum MutationScope {
    Catalog,
    Namespace(NamespaceId),
}

impl MutationScope {
    fn bytes(self) -> Vec<u8> {
        match self {
            Self::Catalog => vec![0],
            Self::Namespace(id) => {
                let mut bytes = vec![1];
                bytes.extend(id.get().to_be_bytes());
                bytes
            }
        }
    }
}

/// Resolved immutable scope. A4 supplies normalized semantic fields; generated
/// IDs/times and provider output must not enter request identity.
#[derive(Debug, Clone)]
pub struct MutationContext {
    pub store_id: Option<Uuid>,
    pub scope: MutationScope,
    pub idempotency_key: Option<String>,
    /// Foundation-only metadata CAS; not public whole-store CAS until all
    /// canonical writers participate in the transaction/effects boundary.
    pub expected_generation: Option<Generation>,
    pub contract_version: u32,
}

impl MutationContext {
    pub fn unkeyed(namespace_id: NamespaceId) -> Self {
        Self {
            store_id: None,
            scope: MutationScope::Namespace(namespace_id),
            idempotency_key: None,
            expected_generation: None,
            contract_version: 1,
        }
    }

    pub(crate) fn validate(&self) -> Result<(), StorageError> {
        if (self.idempotency_key.is_some() || self.expected_generation.is_some())
            && self.store_id.is_none()
        {
            return Err(StorageError::InvalidMutationContext(
                "storeId required with key or expectedGeneration".into(),
            ));
        }
        if let Some(key) = &self.idempotency_key
            && (key.is_empty()
                || key.len() > 128
                || !key.bytes().all(|b| (0x20..=0x7e).contains(&b)))
        {
            return Err(StorageError::InvalidMutationContext(
                "key must be 1–128 printable ASCII bytes".into(),
            ));
        }
        if !matches!(self.contract_version, 1 | 2)
            || matches!(self.scope, MutationScope::Namespace(id) if id.is_unset())
        {
            return Err(StorageError::InvalidMutationContext(
                "unsupported contract version or unset namespace".into(),
            ));
        }
        Ok(())
    }
}

/// One distinct record exposed by a legacy retrieval. No content is retained.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "camelCase", deny_unknown_fields)]
pub struct ExposureOutcome {
    pub memory_id: MemoryId,
    pub kind: crate::model::AccessKind,
    pub accessed_at: i64,
}

/// Payload-free outcome; the timestamp is the originally committed value.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "camelCase", tag = "kind", deny_unknown_fields)]
pub enum MutationOutcome {
    NativeMemoryInserted {
        transition: super::native_records::NativeRecordWrite,
    },
    NativeMemoryTombstoned {
        transition: super::native_records::NativeRecordWrite,
    },
    LifecycleExposureRecorded {
        transition: super::native_lifecycle::NativeLifecycleWrite,
    },
    LifecycleFeedbackApplied {
        transition: super::native_lifecycle::NativeLifecycleWrite,
    },
    LifecycleMaterialized {
        #[serde(rename = "memoryId")]
        memory_id: MemoryId,
        #[serde(rename = "fromPhase")]
        from_phase: crate::model::DecayPhase,
        #[serde(rename = "toPhase")]
        to_phase: crate::model::DecayPhase,
        #[serde(rename = "strengthBits")]
        strength_bits: u32,
        #[serde(rename = "decayStrengthBits")]
        decay_strength_bits: u32,
        #[serde(rename = "removedFieldsMask")]
        removed_fields_mask: u8,
    },
    BatchReserved {
        batch_kind: super::batch::BatchKind,
        item_count: u32,
        caller_hash: [u8; 32],
        resolution_hash: [u8; 32],
    },
    BatchItemRejected {
        batch_operation_id: Uuid,
        index: u32,
        error: super::batch::BatchError,
    },
    NamespacePurgeStarted {
        namespace_id: NamespaceId,
        name_hash: [u8; 32],
    },
    NamespacePurgeAdvanced {
        parent_operation_id: Uuid,
        namespace_id: NamespaceId,
        sequence: u64,
        stage: super::purge::PurgeStage,
        removed: u64,
        tombstones_removed: u64,
        edges_removed: u64,
        last_id: Option<MemoryId>,
    },
    MemoryTombstoned {
        #[serde(rename = "memoryId")]
        memory_id: MemoryId,
        status: super::tombstone::TombstoneStatus,
    },
    MemoryInserted {
        #[serde(rename = "memoryId")]
        memory_id: MemoryId,
        #[serde(rename = "createdAt")]
        created_at: i64,
        #[serde(rename = "initialStabilityBits")]
        initial_stability_bits: u32,
        #[serde(rename = "embeddingDim")]
        embedding_dim: u32,
        #[serde(rename = "edgesPut")]
        edges_put: usize,
    },
    NamespaceCreated {
        #[serde(rename = "namespaceId")]
        namespace_id: NamespaceId,
        #[serde(rename = "createdAt")]
        created_at: i64,
    },
    NamespacePolicyUpdated {
        #[serde(rename = "namespaceId")]
        namespace_id: NamespaceId,
    },
    ExposuresRecorded {
        accesses: Vec<ExposureOutcome>,
    },
    LegacyFeedbackRecorded {
        #[serde(rename = "memoryId")]
        memory_id: MemoryId,
        quality: u8,
        #[serde(rename = "appliedAt")]
        applied_at: i64,
    },
    LifecyclePolicyMigrated {
        transition: super::lifecycle_migration::PolicyTransition,
    },
    GraphChanged {
        edges_put: usize,
        edges_removed: usize,
        memories_removed: usize,
    },
    SchemaMigrated {
        #[serde(rename = "migrationId")]
        migration_id: Uuid,
        #[serde(rename = "recordCount")]
        record_count: u64,
        #[serde(rename = "attestedNamespaces")]
        attested_namespaces: u64,
    },
    TextGenerationSelected {
        #[serde(rename = "generationId")]
        generation_id: Uuid,
        #[serde(rename = "formatVersion")]
        format_version: u16,
        #[serde(rename = "entriesKept")]
        entries_kept: u64,
    },
    AccessRecorded {
        #[serde(rename = "memoryId")]
        memory_id: MemoryId,
        #[serde(rename = "accessedAt")]
        accessed_at: i64,
    },
}

/// Evidence of canonical metadata commit only, never of derived-index readiness.
/// Replay returns historical numbers/IDs; callers must revalidate content.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct WriteReceipt {
    pub store_id: Uuid,
    pub operation_id: Uuid,
    pub committed_generation: Generation,
    pub receipt_version: u32,
    pub outcome: MutationOutcome,
    pub replayed: bool,
}

#[derive(Serialize, Deserialize)]
pub(crate) struct StoredReceipt {
    pub request_hash_version: u32,
    pub request_hash: [u8; 32],
    pub receipt: WriteReceipt,
}

pub(crate) fn encode(value: &impl Serialize) -> Result<Vec<u8>, StorageError> {
    serde_json::to_vec(value).map_err(|e| StorageError::Serialize(e.to_string()))
}

pub(crate) fn decode<T: serde::de::DeserializeOwned>(bytes: &[u8]) -> Result<T, StorageError> {
    serde_json::from_slice(bytes).map_err(|e| StorageError::InvalidControl(e.to_string()))
}

/// Read-only validation shared by metadata startup and staged backup/restore.
/// Absence of the entire additive schema is a legacy store; partial presence,
/// conflicting table types and unknown versions are never legacy adoption.
pub(crate) fn validate_existing(
    tx: &ReadTransaction,
) -> Result<Option<ControlState>, StorageError> {
    #[cfg(test)]
    VALIDATION_WORK.with(|work| {
        let mut count = work.get();
        count.full_validations += 1;
        work.set(count);
    });
    let reserved = [CONTROL.name(), RECEIPTS.name(), KEYS.name()];
    if tx.list_multimap_tables()?.any(|table| {
        reserved.contains(&table.name()) || table.name() == super::canonical_schema::SCHEMA.name()
    }) {
        return Err(StorageError::InvalidControl(
            "control table is a multimap".into(),
        ));
    }
    let names: Vec<_> = tx
        .list_tables()?
        .map(|table| table.name().to_owned())
        .collect();
    let present = reserved.map(|name| names.iter().any(|n| n == name));
    if !present.iter().any(|p| *p) {
        if names
            .iter()
            .any(|n| n == super::canonical_schema::SCHEMA.name())
        {
            return Err(StorageError::InvalidControl(
                "schema without control lineage".into(),
            ));
        }
        super::metadata::purge::validate_existing(tx, None)?;
        super::metadata::batch::validate_existing(tx, None)?;
        return Ok(None);
    }
    if !present.iter().all(|p| *p) {
        return Err(StorageError::InvalidControl(
            "incomplete control tables".into(),
        ));
    }
    let control = tx.open_table(CONTROL)?;
    let receipts = tx.open_table(RECEIPTS)?;
    let keys = tx.open_table(KEYS)?;
    if control.len()? != 1 {
        return Err(StorageError::InvalidControl(
            "control must contain exactly one state row".into(),
        ));
    }
    let state = ControlState::decode(
        control
            .get("state")?
            .ok_or_else(|| StorageError::InvalidControl("missing control state".into()))?
            .value(),
    )?;
    let ancestry = super::lineage::read_lineage(tx, &state)?;
    super::canonical_schema::read_state(tx, &state)?;
    for entry in receipts.iter()? {
        let (key, value) = entry?;
        let (lineage, scope, operation) = decode_scope(key.value())?;
        let stored = validate_receipt(value.value())?;
        let scope_matches = match &stored.receipt.outcome {
            MutationOutcome::NamespaceCreated { .. }
            | MutationOutcome::BatchReserved { .. }
            | MutationOutcome::BatchItemRejected { .. } => scope == MutationScope::Catalog,
            MutationOutcome::NamespacePolicyUpdated { namespace_id }
            | MutationOutcome::NamespacePurgeStarted { namespace_id, .. }
            | MutationOutcome::NamespacePurgeAdvanced { namespace_id, .. } => {
                scope == MutationScope::Namespace(*namespace_id)
            }
            MutationOutcome::MemoryInserted { .. }
            | MutationOutcome::MemoryTombstoned { .. }
            | MutationOutcome::LifecycleMaterialized { .. } => {
                matches!(scope, MutationScope::Namespace(_))
            }
            _ => true,
        };
        if !scope_matches {
            return Err(StorageError::InvalidControl(
                if matches!(
                    stored.receipt.outcome,
                    MutationOutcome::MemoryInserted { .. }
                        | MutationOutcome::MemoryTombstoned { .. }
                ) {
                    "record mutation receipt has catalog scope"
                } else {
                    "catalog receipt outcome disagrees with key scope"
                }
                .into(),
            ));
        }
        // Policy receipts require the canonical schema consumer even when the
        // schema table is entirely absent. Legacy decode alone is not proof.
        if matches!(
            stored.receipt.outcome,
            MutationOutcome::LifecyclePolicyMigrated { .. }
                | MutationOutcome::LifecycleExposureRecorded { .. }
                | MutationOutcome::LifecycleFeedbackApplied { .. }
                | MutationOutcome::NativeMemoryInserted { .. }
                | MutationOutcome::NativeMemoryTombstoned { .. }
        ) && state.control_schema_version != 2
        {
            return Err(StorageError::InvalidControl(
                "lifecycle policy receipt requires canonical schema 2".into(),
            ));
        }
        let permitted_origin = if lineage == state.store_id {
            stored.receipt.committed_generation <= state.committed_generation
        } else {
            ancestry.as_ref().is_some_and(|a| {
                a.permits(GenerationRef {
                    store_id: lineage,
                    generation: stored.receipt.committed_generation,
                })
            })
        };
        if !permitted_origin
            || stored.receipt.store_id != lineage
            || operation != stored.receipt.operation_id.as_bytes()
            || (matches!(
                stored.receipt.outcome,
                MutationOutcome::ExposuresRecorded { .. }
                    | MutationOutcome::LegacyFeedbackRecorded { .. }
            ) && !matches!(scope, MutationScope::Namespace(_)))
        {
            return Err(StorageError::InvalidControl(
                "receipt identity/generation disagrees with control".into(),
            ));
        }
    }
    for entry in keys.iter()? {
        let (key, value) = entry?;
        let (lineage, scope, client_key) = decode_scope(key.value())?;
        let (receipt_lineage, receipt_scope, _) = decode_scope(value.value())?;
        if (lineage != state.store_id
            && !ancestry
                .as_ref()
                .is_some_and(|a| a.ancestors.iter().any(|r| r.store_id == lineage)))
            || lineage != receipt_lineage
            || scope != receipt_scope
            || client_key.is_empty()
            || client_key.len() > 128
            || !client_key.iter().all(|b| (0x20..=0x7e).contains(b))
            || receipts.get(value.value())?.is_none()
        {
            return Err(StorageError::InvalidControl(
                "invalid retry key or receipt reference".into(),
            ));
        }
    }
    super::metadata::purge::validate_existing(tx, Some(&state))?;
    super::metadata::batch::validate_existing(tx, Some(&state))?;
    Ok(Some(state))
}

fn decode_scope(key: &[u8]) -> Result<(Uuid, MutationScope, &[u8]), StorageError> {
    let invalid = || StorageError::InvalidControl("invalid receipt/key scope encoding".into());
    let lineage = Uuid::from_slice(key.get(..16).ok_or_else(invalid)?).map_err(|_| invalid())?;
    match key.get(16) {
        Some(0) => Ok((lineage, MutationScope::Catalog, &key[17..])),
        Some(1) if key.len() >= 21 => {
            let ns = NamespaceId::new(u32::from_be_bytes(key[17..21].try_into().unwrap()));
            if ns.is_unset() {
                return Err(invalid());
            }
            Ok((lineage, MutationScope::Namespace(ns), &key[21..]))
        }
        _ => Err(invalid()),
    }
}

/// One-time adoption at generation zero; a present but incomplete control schema
/// is corruption, not permission to mint a new retry lineage.
pub(crate) fn initialize_with_ids(
    tx: &WriteTransaction,
    ids: &dyn super::ids::IdSource,
) -> Result<(), StorageError> {
    let names: Vec<_> = tx.list_tables()?.map(|t| t.name().to_owned()).collect();
    let present =
        [CONTROL.name(), RECEIPTS.name(), KEYS.name()].map(|n| names.iter().any(|s| s == n));
    if present.iter().any(|p| *p) {
        if !present.iter().all(|p| *p) {
            return Err(StorageError::InvalidControl(
                "incomplete control tables".into(),
            ));
        }
        read_control(tx)?;
    } else {
        let state = ControlState {
            control_schema_version: 1,
            store_id: ids.uuid(super::ids::IdKind::Store)?,
            committed_generation: Generation::default(),
            removal_ledger_version: None,
            restore_lineage_version: None,
        };
        tx.open_table(CONTROL)?
            .insert("state", encode(&state)?.as_slice())?;
        tx.open_table(RECEIPTS)?;
        tx.open_table(KEYS)?;
    }
    Ok(())
}

pub(crate) fn read_control(tx: &WriteTransaction) -> Result<ControlState, StorageError> {
    let table = tx.open_table(CONTROL)?;
    let value = table
        .get("state")?
        .ok_or_else(|| StorageError::InvalidControl("missing control state".into()))?;
    ControlState::decode(value.value())
}

/// Called inside each canonical metadata transaction, not checkpoint writes.
pub(crate) fn advance_generation(tx: &WriteTransaction) -> Result<ControlState, StorageError> {
    let mut state = read_control(tx)?;
    state.committed_generation = state.committed_generation.next()?;
    tx.open_table(CONTROL)?
        .insert("state", encode(&state)?.as_slice())?;
    Ok(state)
}

/// SHA-256 requestHashVersion 1: every component has a u64 BE byte-length.
/// Field order is semantic. Callers must normalize defaults/object keys first;
/// arrays preserve order and supplied float embeddings use their exact bytes.
pub(crate) fn request_hash(ctx: &MutationContext, operation: &str, fields: &[&[u8]]) -> [u8; 32] {
    let mut hash = Sha256::new();
    let expected = ctx.expected_generation.map(String::from);
    let scope = ctx.scope.bytes();
    let version = ctx.contract_version.to_be_bytes();
    for part in [
        operation.as_bytes(),
        version.as_slice(),
        scope.as_slice(),
        expected.as_deref().unwrap_or("").as_bytes(),
    ]
    .into_iter()
    .chain(fields.iter().copied())
    {
        hash.update((part.len() as u64).to_be_bytes());
        hash.update(part);
    }
    hash.finalize().into()
}

pub(crate) fn scoped_key(store_id: Uuid, scope: MutationScope, suffix: &[u8]) -> Vec<u8> {
    let mut key = store_id.as_bytes().to_vec();
    key.extend(scope.bytes());
    key.extend(suffix);
    key
}

pub(crate) fn validate_receipt(bytes: &[u8]) -> Result<StoredReceipt, StorageError> {
    #[cfg(test)]
    VALIDATION_WORK.with(|work| {
        let mut count = work.get();
        count.receipt_decodes += 1;
        work.set(count);
    });
    let stored: StoredReceipt = decode(bytes)?;
    if stored.request_hash_version != 1
        || stored.receipt.receipt_version != 1
        || stored.receipt.store_id.is_nil()
        || stored.receipt.operation_id.is_nil()
        || stored.receipt.committed_generation == Generation::default()
        || stored.receipt.replayed
    {
        return Err(StorageError::InvalidControl(
            "unsupported receipt/hash version or invalid persisted receipt".into(),
        ));
    }
    match &stored.receipt.outcome {
        MutationOutcome::NativeMemoryInserted { transition } => {
            transition.validate(&stored.receipt, true)?
        }
        MutationOutcome::NativeMemoryTombstoned { transition } => {
            transition.validate(&stored.receipt, false)?
        }
        MutationOutcome::LifecycleExposureRecorded { transition } => {
            transition.validate(&stored.receipt, false)?
        }
        MutationOutcome::LifecycleFeedbackApplied { transition } => {
            transition.validate(&stored.receipt, true)?
        }
        MutationOutcome::MemoryInserted { .. }
        | MutationOutcome::MemoryTombstoned { .. }
        | MutationOutcome::LifecycleMaterialized { .. }
        | MutationOutcome::BatchReserved { .. }
        | MutationOutcome::BatchItemRejected { .. }
        | MutationOutcome::ExposuresRecorded { .. }
        | MutationOutcome::LegacyFeedbackRecorded { .. }
        | MutationOutcome::LifecyclePolicyMigrated { .. }
        | MutationOutcome::GraphChanged { .. }
        | MutationOutcome::SchemaMigrated { .. }
        | MutationOutcome::TextGenerationSelected { .. }
        | MutationOutcome::AccessRecorded { .. }
        | MutationOutcome::NamespaceCreated { .. }
        | MutationOutcome::NamespacePolicyUpdated { .. }
        | MutationOutcome::NamespacePurgeStarted { .. }
        | MutationOutcome::NamespacePurgeAdvanced { .. } => {}
    }
    if let MutationOutcome::MemoryInserted {
        memory_id,
        created_at,
        edges_put,
        initial_stability_bits,
        embedding_dim,
    } = stored.receipt.outcome
    {
        if memory_id == MemoryId::nil()
            || chrono::DateTime::from_timestamp_millis(created_at).is_none()
            || edges_put > 2
            || !(1..=8192).contains(&embedding_dim)
            || !f32::from_bits(initial_stability_bits).is_finite()
            || f32::from_bits(initial_stability_bits) <= 0.0
        {
            return Err(StorageError::InvalidControl(
                "invalid insertion receipt".into(),
            ));
        }
    }
    if matches!(stored.receipt.outcome, MutationOutcome::MemoryTombstoned { memory_id, .. } if memory_id == MemoryId::nil())
    {
        return Err(StorageError::InvalidControl(
            "nil tombstone receipt identity".into(),
        ));
    }
    if let MutationOutcome::LifecycleMaterialized {
        memory_id,
        from_phase,
        to_phase,
        strength_bits,
        decay_strength_bits,
        removed_fields_mask,
    } = stored.receipt.outcome
    {
        use crate::model::DecayPhase::{Full, Ghost, Summary, Tombstone};
        if memory_id == MemoryId::nil()
            || from_phase == Tombstone
            || to_phase == Tombstone
            || !(from_phase == to_phase
                || matches!((from_phase, to_phase), (Full, Summary) | (Summary, Ghost)))
            || [strength_bits, decay_strength_bits].iter().any(|bits| {
                !f32::from_bits(*bits).is_finite() || !(0.0..=1.0).contains(&f32::from_bits(*bits))
            })
            || removed_fields_mask
                != match (from_phase, to_phase) {
                    (Full, Summary) => super::metadata::removal_ledger::FULL_TEXT,
                    (Summary, Ghost) => super::metadata::removal_ledger::SUMMARY,
                    _ => 0,
                }
        {
            return Err(StorageError::InvalidControl(
                "invalid lifecycle materialization receipt".into(),
            ));
        }
    }
    match &stored.receipt.outcome {
        MutationOutcome::NamespaceCreated {
            namespace_id,
            created_at,
        } if namespace_id.is_unset()
            || chrono::DateTime::from_timestamp_millis(*created_at).is_none() =>
        {
            return Err(StorageError::InvalidControl(
                "invalid catalog receipt".into(),
            ));
        }
        MutationOutcome::NamespacePolicyUpdated { namespace_id } if namespace_id.is_unset() => {
            return Err(StorageError::InvalidControl(
                "invalid catalog receipt".into(),
            ));
        }
        _ => {}
    }
    match &stored.receipt.outcome {
        MutationOutcome::ExposuresRecorded { accesses } => {
            let mut seen = std::collections::HashSet::new();
            if accesses.is_empty()
                || accesses.iter().any(|a| {
                    a.memory_id == MemoryId::nil()
                        || chrono::DateTime::from_timestamp_millis(a.accessed_at).is_none()
                        || !seen.insert(a.memory_id)
                        || !matches!(
                            a.kind,
                            crate::model::AccessKind::DirectRetrieval
                                | crate::model::AccessKind::AssociativeRetrieval
                        )
                })
            {
                return Err(StorageError::InvalidControl(
                    "invalid exposure receipt outcome".into(),
                ));
            }
        }
        MutationOutcome::LegacyFeedbackRecorded {
            memory_id,
            quality,
            applied_at,
        } => {
            if *memory_id == MemoryId::nil()
                || !(1..=4).contains(quality)
                || chrono::DateTime::from_timestamp_millis(*applied_at).is_none()
            {
                return Err(StorageError::InvalidControl(
                    "invalid feedback receipt outcome".into(),
                ));
            }
        }
        MutationOutcome::AccessRecorded { .. }
        | MutationOutcome::NativeMemoryInserted { .. }
        | MutationOutcome::NativeMemoryTombstoned { .. }
        | MutationOutcome::LifecycleExposureRecorded { .. }
        | MutationOutcome::LifecycleFeedbackApplied { .. }
        | MutationOutcome::GraphChanged { .. }
        | MutationOutcome::SchemaMigrated { .. }
        | MutationOutcome::TextGenerationSelected { .. }
        | MutationOutcome::LifecyclePolicyMigrated { .. } => {}
        MutationOutcome::BatchReserved { .. }
        | MutationOutcome::BatchItemRejected { .. }
        | MutationOutcome::MemoryInserted { .. }
        | MutationOutcome::MemoryTombstoned { .. }
        | MutationOutcome::LifecycleMaterialized { .. }
        | MutationOutcome::NamespaceCreated { .. }
        | MutationOutcome::NamespacePolicyUpdated { .. }
        | MutationOutcome::NamespacePurgeStarted { .. }
        | MutationOutcome::NamespacePurgeAdvanced { .. } => {}
    }
    Ok(stored)
}

/// Lookup before resolving mutable defaults. Operation-specific callers can
/// reconstruct normalization from a payload-free historical outcome, then use
/// replay_or_check to verify the complete hash before accepting replay.
pub(crate) fn keyed_receipt(
    tx: &WriteTransaction,
    ctx: &MutationContext,
) -> Result<Option<StoredReceipt>, StorageError> {
    ctx.validate()?;
    let state = read_control(tx)?;
    if ctx.store_id.is_some_and(|id| id != state.store_id) {
        return Err(StorageError::StoreLineageMismatch);
    }
    let Some(key) = &ctx.idempotency_key else {
        return Ok(None);
    };
    let keys = tx.open_table(KEYS)?;
    let Some(id) = keys.get(scoped_key(state.store_id, ctx.scope, key.as_bytes()).as_slice())?
    else {
        return Ok(None);
    };
    let receipts = tx.open_table(RECEIPTS)?;
    let value = receipts
        .get(id.value())?
        .ok_or_else(|| StorageError::InvalidControl("key without receipt".into()))?;
    validate_receipt(value.value()).map(Some)
}

/// Lineage precedes replay; matching replay precedes CAS (including after purge).
pub(crate) fn replay_or_check(
    tx: &WriteTransaction,
    ctx: &MutationContext,
    hash: [u8; 32],
) -> Result<Option<WriteReceipt>, StorageError> {
    ctx.validate()?;
    let state = read_control(tx)?;
    if ctx.store_id.is_some_and(|id| id != state.store_id) {
        return Err(StorageError::StoreLineageMismatch);
    }
    if let Some(key) = &ctx.idempotency_key {
        let keys = tx.open_table(KEYS)?;
        if let Some(id) =
            keys.get(scoped_key(state.store_id, ctx.scope, key.as_bytes()).as_slice())?
        {
            let receipts = tx.open_table(RECEIPTS)?;
            let stored = receipts
                .get(id.value())?
                .ok_or_else(|| StorageError::InvalidControl("key without receipt".into()))?;
            let mut stored = validate_receipt(stored.value())?;
            if stored.request_hash != hash {
                return Err(StorageError::IdempotencyConflict);
            }
            stored.receipt.replayed = true;
            return Ok(Some(stored.receipt));
        }
    }
    if let Some(expected) = ctx.expected_generation
        && expected != state.committed_generation
    {
        return Err(StorageError::GenerationConflict {
            expected: expected.into(),
            actual: state.committed_generation.into(),
        });
    }
    Ok(None)
}

/// Caller commits this same transaction with its metadata changes. No payload
/// copies are retained; no receipt/key expiry or namespace-delete cleanup.
pub(crate) fn record_receipt(
    tx: &WriteTransaction,
    ctx: &MutationContext,
    hash: [u8; 32],
    outcome: MutationOutcome,
) -> Result<WriteReceipt, StorageError> {
    record_receipt_with_ids(tx, ctx, hash, outcome, &super::ids::SystemIds)
}

pub(crate) fn record_receipt_with_ids(
    tx: &WriteTransaction,
    ctx: &MutationContext,
    hash: [u8; 32],
    outcome: MutationOutcome,
    ids: &dyn super::ids::IdSource,
) -> Result<WriteReceipt, StorageError> {
    record_reserved_receipt(
        tx,
        ctx,
        hash,
        outcome,
        ids.uuid(super::ids::IdKind::Operation)?,
    )
}

/// Internal transaction primitive. Purge callers must first prove a durable
/// reservation; external requests cannot choose an operation identity.
pub(super) fn record_reserved_receipt(
    tx: &WriteTransaction,
    ctx: &MutationContext,
    hash: [u8; 32],
    outcome: MutationOutcome,
    operation_id: Uuid,
) -> Result<WriteReceipt, StorageError> {
    let before = read_control(tx)?;
    if operation_id.is_nil()
        || tx
            .open_table(RECEIPTS)?
            .get(scoped_key(before.store_id, ctx.scope, operation_id.as_bytes()).as_slice())?
            .is_some()
    {
        return Err(StorageError::InvalidControl(
            "receipt operation ID already used or nil".into(),
        ));
    }
    let state = advance_generation(tx)?;
    let receipt = WriteReceipt {
        store_id: state.store_id,
        operation_id,
        committed_generation: state.committed_generation,
        receipt_version: 1,
        outcome,
        replayed: false,
    };
    let key = scoped_key(state.store_id, ctx.scope, receipt.operation_id.as_bytes());
    tx.open_table(RECEIPTS)?.insert(
        key.as_slice(),
        encode(&StoredReceipt {
            request_hash_version: 1,
            request_hash: hash,
            receipt: receipt.clone(),
        })?
        .as_slice(),
    )?;
    if let Some(client_key) = &ctx.idempotency_key {
        tx.open_table(KEYS)?.insert(
            scoped_key(state.store_id, ctx.scope, client_key.as_bytes()).as_slice(),
            key.as_slice(),
        )?;
    }
    Ok(receipt)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn generation_is_canonical_decimal_u63_not_json_number() {
        for n in ["0", "1", "9007199254740993", "9223372036854775807"] {
            let json = format!("\"{n}\"");
            let value: Generation = serde_json::from_str(&json).unwrap();
            assert_eq!(serde_json::to_string(&value).unwrap(), json);
        }
        for json in [
            "0",
            "42",
            "null",
            "\"\"",
            "\"01\"",
            "\"+1\"",
            "\"-1\"",
            "\" 1\"",
            "\"1.0\"",
            "\"1e2\"",
            "\"9223372036854775808\"",
            "\"18446744073709551616\"",
        ] {
            assert!(serde_json::from_str::<Generation>(json).is_err(), "{json}");
        }
        assert!(matches!(
            Generation::MAX.next(),
            Err(StorageError::GenerationExhausted)
        ));
    }

    #[test]
    fn request_identity_is_length_delimited_ordered_and_operation_scoped() {
        let ctx = MutationContext::unkeyed(NamespaceId::new(1));
        let hash = request_hash(&ctx, "access", &[b"ab", b"c"]);
        assert_ne!(hash, request_hash(&ctx, "access", &[b"a", b"bc"]));
        assert_ne!(hash, request_hash(&ctx, "access", &[b"c", b"ab"]));
        assert_ne!(hash, request_hash(&ctx, "forget", &[b"ab", b"c"]));
        let mut changed = ctx.clone();
        changed.scope = MutationScope::Catalog;
        assert_ne!(hash, request_hash(&changed, "access", &[b"ab", b"c"]));
        changed = ctx.clone();
        changed.contract_version = 2;
        assert_ne!(hash, request_hash(&changed, "access", &[b"ab", b"c"]));
        changed = ctx.clone();
        changed.expected_generation = Some(Generation::default());
        assert_ne!(hash, request_hash(&changed, "access", &[b"ab", b"c"]));
        changed = ctx.clone();
        changed.idempotency_key = Some("transport-independent-key".into());
        assert_eq!(hash, request_hash(&changed, "access", &[b"ab", b"c"]));
        assert_ne!(
            scoped_key(Uuid::nil(), MutationScope::Catalog, b"x"),
            scoped_key(Uuid::nil(), ctx.scope, b"x")
        );
    }

    #[test]
    fn retry_context_requires_lineage_and_valid_key_scope_version() {
        let mut ctx = MutationContext::unkeyed(NamespaceId::new(1));
        ctx.expected_generation = Some(Generation::default());
        assert!(ctx.validate().is_err());
        ctx.expected_generation = None;
        ctx.idempotency_key = Some("key".into());
        assert!(ctx.validate().is_err());
        ctx.store_id = Some(Uuid::new_v4());
        assert!(ctx.validate().is_ok());
        for key in [String::new(), "x".repeat(129), "tab\t".into(), "é".into()] {
            ctx.idempotency_key = Some(key);
            assert!(ctx.validate().is_err());
        }
        ctx.idempotency_key = None;
        ctx.scope = MutationScope::Namespace(NamespaceId::UNSET);
        assert!(ctx.validate().is_err());
        ctx.scope = MutationScope::Catalog;
        ctx.contract_version = 3;
        assert!(ctx.validate().is_err());
    }

    #[test]
    fn policy_receipt_requires_canonical_schema_before_writable_startup() {
        use crate::model::schema::LifecycleVersion;
        use crate::storage::{MetadataStore, lifecycle_migration::PolicyTransition};
        let dir = tempfile::tempdir().unwrap();
        let path = dir.path().join("meta.db");
        drop(MetadataStore::open(&path).unwrap());
        let db = redb::Database::open(&path).unwrap();
        let tx = db.begin_write().unwrap();
        let state = read_control(&tx).unwrap();
        let ctx = MutationContext {
            store_id: Some(state.store_id),
            scope: MutationScope::Namespace(NamespaceId::new(1)),
            idempotency_key: Some("forged-policy".into()),
            expected_generation: Some(state.committed_generation),
            contract_version: 1,
        };
        record_receipt(
            &tx,
            &ctx,
            [7; 32],
            MutationOutcome::LifecyclePolicyMigrated {
                transition: PolicyTransition {
                    namespace_id: NamespaceId::new(1),
                    from: LifecycleVersion::LegacyAccessV1,
                    to: LifecycleVersion::ExplicitFeedbackV2,
                    previous_revision: Generation::default(),
                    next_revision: Generation::default().next().unwrap(),
                    previous_generation: state.committed_generation,
                    record_count: 0,
                    record_token_digest:
                        "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855".into(),
                },
            },
        )
        .unwrap();
        tx.commit().unwrap();
        let rejected = validate_existing(&db.begin_read().unwrap()).is_err();
        drop(db);
        assert!(
            rejected,
            "legacy control without a canonical schema must reject policy receipts"
        );
        let before = std::fs::read(&path).unwrap();
        assert!(MetadataStore::open(&path).is_err());
        assert_eq!(
            std::fs::read(&path).unwrap(),
            before,
            "rejection precedes writable redb open"
        );
    }
}
