set -eu
mkdir -p /tmp/home
cd /work/source
python3 scripts/test_public_mcp_evaluation.py > /work/output/python-tests.log 2>&1
cargo fmt --all --check > /work/output/fmt.log 2>&1
cargo test --offline --locked --example score_mcp_episode > /work/output/example-tests.log 2>&1
cargo build --offline --locked --bin recalld --example score_mcp_episode > /work/output/build.log 2>&1
python3 scripts/public-mcp-evaluation.py prepare --track serialized-mcp-synthetic-conformance-v1 --binary /work/target/debug/recalld --scorer /work/target/debug/examples/score_mcp_episode --build /work/output/build.json --out /work/output/inputs
python3 scripts/public-mcp-evaluation.py run --binary /work/target/debug/recalld --scorer /work/target/debug/examples/score_mcp_episode --source-root /work/source --manifest /work/output/inputs/manifest.json --out /work/output/episode-0
