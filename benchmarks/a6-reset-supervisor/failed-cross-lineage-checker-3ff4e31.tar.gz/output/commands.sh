set -eu
mkdir -p /tmp/home
trap 'cat /sys/fs/cgroup/memory.events > /work/output/memory-events.txt; cat /sys/fs/cgroup/memory.peak > /work/output/memory-peak.txt' EXIT
rustc -Vv > /work/output/rustc.txt
cat /sys/fs/cgroup/cpu.max > /work/output/cgroup-cpu.txt
cat /sys/fs/cgroup/memory.max > /work/output/cgroup-memory.txt
python3 scripts/test_public_mcp_evaluation.py > /work/output/consumer-python.log 2>&1
cargo build --offline --locked --features bench --example owned_evaluator --example score_mcp_episode -j1 > /work/output/build.log 2>&1
sha256sum /work/target/debug/examples/owned_evaluator /work/target/debug/examples/score_mcp_episode > /work/output/consumer-binaries-before.sha256
python3 scripts/public-mcp-evaluation.py prepare --track serialized-owned-reset-synthetic-diagnostic-v1 --binary /work/target/debug/examples/owned_evaluator --scorer /work/target/debug/examples/score_mcp_episode --build /work/output/build.json --out /work/output/inputs > /work/output/prepare.log 2>&1
python3 scripts/public-mcp-evaluation.py run --binary /work/target/debug/examples/owned_evaluator --scorer /work/target/debug/examples/score_mcp_episode --source-root /work/source --manifest /work/output/inputs/manifest.json --out /work/output/episode-0 > /work/output/episode.log 2>&1
python3 scripts/test_reset_mcp_episode.py --source /work/source --inputs /work/output/inputs --baseline /work/output/episode-0 --binary /work/target/debug/examples/owned_evaluator --scorer /work/target/debug/examples/score_mcp_episode --out /work/output/canaries > /work/output/canaries.log 2>&1
sha256sum /work/target/debug/examples/owned_evaluator /work/target/debug/examples/score_mcp_episode > /work/output/consumer-binaries-after.sha256
cmp /work/output/consumer-binaries-before.sha256 /work/output/consumer-binaries-after.sha256
