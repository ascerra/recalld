import json,hashlib,sys
from pathlib import Path
root=Path(sys.argv[1]);differences={}
def diff(a,b,path=''):
 if type(a)!=type(b):return [{'path':path,'before':a,'after':b}]
 if isinstance(a,dict):
  out=[]
  for k in sorted(a.keys()|b.keys()):
   if k not in a or k not in b:out.append({'path':path+'/'+k,'before':a.get(k),'after':b.get(k)})
   else:out+=diff(a[k],b[k],path+'/'+k)
  return out
 if isinstance(a,list):
  if len(a)!=len(b):return [{'path':path+'/length','before':len(a),'after':len(b)}]
  return [v for i,(x,y) in enumerate(zip(a,b)) for v in diff(x,y,path+'/'+str(i))]
 return [] if a==b else [{'path':path,'before':a,'after':b}]
for phase in ('prefix','suffix'):
 documents=[json.loads((root/f'{name}-{phase}.json').read_text()) for name in ('baseline','changed')]
 for d in documents:
  h=hashlib.sha256(d['sourceEncodedUtf8'].encode());h.update(d['domain'].encode())
  for item in d['items']:
   raw=item['encodedUtf8'].encode();assert hashlib.sha256(raw).hexdigest()==item['encodedSha256']
   if item['includedInLogicalHash']:h.update(len(raw).to_bytes(8,'big'));h.update(raw)
  assert h.hexdigest()==d['logicalSha256']
 a,b=documents;assert len(a['items'])==len(b['items'])
 changed=[];excluded=[]
 for x,y in zip(a['items'],b['items']):
  assert x['index']==y['index'] and x['includedInLogicalHash']==y['includedInLogicalHash']
  if x['encodedUtf8']!=y['encodedUtf8']:
   record={'index':x['index'],'beforeEncodedSha256':x['encodedSha256'],'afterEncodedSha256':y['encodedSha256'],'diff':diff(json.loads(x['encodedUtf8']),json.loads(y['encodedUtf8']))}
   xv,yv=json.loads(x['encodedUtf8']),json.loads(y['encodedUtf8'])
   if xv['kind']=='row' and yv['kind']=='row':
    try:
     decoded_a=json.loads(bytes(xv['data']['value']));decoded_b=json.loads(bytes(yv['data']['value']))
    except (ValueError,UnicodeError):pass
    else:record['decodedJsonValueDiff']=diff(decoded_a,decoded_b);record['rowKeyHex']=bytes(xv['data']['key']).hex()
   (changed if x['includedInLogicalHash'] else excluded).append(record)
 differences[phase]={'beforeHash':a['logicalSha256'],'afterHash':b['logicalSha256'],'sourceDiff':diff(a['source'],b['source']),'items':len(a['items']),'included':sum(x['includedInLogicalHash'] for x in a['items']),'changedIncludedItems':changed,'changedExcludedItems':excluded,'independentlyReproducedBothHashes':True}
(root/'typed-input-diff.json').write_text(json.dumps(differences,indent=2)+'\n');print(json.dumps(differences,indent=2))
