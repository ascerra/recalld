import hashlib,json,shutil
from pathlib import Path
base=Path('/tmp/recalld-reset-supervisor-3ff4e313-g7e6wsm8/output')
paths={
'baseline-prefix':'episode-0/runtime/recalld-frozen-canonical-Iv4uBI',
'changed-prefix':'canaries/changed-label-episode/runtime/recalld-frozen-canonical-4vcCKt',
'baseline-suffix':'episode-0/runtime/recalld-frozen-canonical-SqEUvO',
'changed-suffix':'canaries/changed-label-episode/runtime/recalld-frozen-canonical-FXI3d3',
}
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
records={}
for name,relative in paths.items():
 source=base/relative; manifest=source/'manifest.json'; d=json.loads(manifest.read_text()); dest=root/'inputs'/name; dest.mkdir(parents=True)
 copied={}
 for rel,expected in d['filesSha256'].items():
  path=Path(rel); assert not path.is_absolute() and '..' not in path.parts
  original=source/'canonical'/path
  assert original.is_file() and not original.is_symlink(),original
  assert sha(original)==expected,(original,'input mismatch')
  target=dest/'canonical'/path; target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(original,target)
  assert sha(original)==sha(target)==expected
  copied[rel]=expected
 shutil.copyfile(manifest,dest/'manifest.json')
 records[name]={'manifest':str(manifest),'manifestSha256':sha(manifest),'sourceFilesSha256':copied,'copyVerified':True}
(out/'inputs.json').write_text(json.dumps(records,indent=2)+'\n')
(out/'stage-inputs.py').write_bytes(Path(__file__).read_bytes())
