import hashlib, importlib.util, json, os, subprocess, sys, tempfile
from pathlib import Path
sys.dont_write_bytecode=True
SOURCE=Path('/tmp/recalld-implementation/coherent-rif-consumer')
HARNESS=Path('/tmp/recalld-implementation/observed-consumer-evidence/scripts/public-conformance.py')
IMAGE='sha256:daefdc9cbe9b0f39b1fc29d975148b3b10adc1bd4309f9ca1be8abd36ed811ef'
spec=importlib.util.spec_from_file_location('runner',HARNESS);runner=importlib.util.module_from_spec(spec);spec.loader.exec_module(runner)
commit=runner.git(SOURCE,'rev-parse','HEAD').decode().strip()
root=Path(tempfile.mkdtemp(prefix='recalld-coherent-rif-'+commit[:8]+'-',dir='/tmp'))
for n in ['output','cargo','target']: (root/n).mkdir()
seed=Path(sys.argv[1]) if len(sys.argv)>1 else None
if seed:
    assert seed.name=='target' and str(seed).startswith(('/tmp/recalld-checkpoint2-', '/tmp/recalld-coherent-rif-'))
    subprocess.run(['/bin/cp','-cR',str(seed)+'/.',str(root/'target')],check=True)
out=root/'output'
(out/'driver.py').write_bytes(Path(__file__).read_bytes())
prov,patch=runner.snapshot(SOURCE,root/'source',extra=('src/storage/metadata/native_records/fixtures/phase-clock-legacy.jsonl',),expected_commit=commit)
(out/'source.patch').write_bytes(patch)
runner.save(out/'source-before.json',prov)
(root/'output'/'binary-hashes.py').write_text('''import hashlib,json,os,sys\nfrom pathlib import Path\nr=Path('/work/target/debug')\nfiles=[p for p in r.rglob('*') if p.is_file() and os.access(p,os.X_OK) and (p.parent==r or p.parent==r/'deps') and p.name.startswith(('recalld','lifecycle_cli-','text_migration_cli-'))]\nprint(json.dumps({str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(files)},indent=2))\n''')
script='''set -eu
mkdir -p /tmp/home
trap 'cat /sys/fs/cgroup/memory.events > /work/output/memory-events.txt; cat /sys/fs/cgroup/memory.peak > /work/output/memory-peak.txt' EXIT
rustc -Vv > /work/output/rustc.txt
cat /sys/fs/cgroup/cpu.max > /work/output/cgroup-cpu.txt
cat /sys/fs/cgroup/memory.max > /work/output/cgroup-memory.txt
cargo fmt --all --check > /work/output/fmt.log 2>&1
cargo clean -p recalld > /work/output/package-clean.log 2>&1
cargo test --offline --locked --all-features --lib --bins --tests --examples --no-run -j1 > /work/output/compile.log 2>&1
python3 /work/output/binary-hashes.py > /work/output/test-binaries-before.json
cargo test --offline --locked --all-features --lib rif_ -j1 > /work/output/focused-rif.log 2>&1
cargo test --offline --locked --all-features --lib coherent_payload_ -j1 > /work/output/focused-payload.log 2>&1
cargo test --offline --locked --all-features --lib --bins --tests --examples -j1 > /work/output/full-suite.log 2>&1
python3 /work/output/binary-hashes.py > /work/output/test-binaries-after.json
cmp /work/output/test-binaries-before.json /work/output/test-binaries-after.json
cargo clippy --offline --locked --all-features --all-targets -j1 > /work/output/clippy.log 2>&1
python3 scripts/test_public_conformance.py > /work/output/runner-tests.log 2>&1
cargo build --offline --locked --bin recalld -j1 > /work/output/build.log 2>&1
sha256sum /work/target/debug/recalld > /work/output/public-binary-before.sha256
python3 scripts/public-conformance.py --inside --fixture-version 3 > /work/output/public-runner.log 2>&1
sha256sum /work/target/debug/recalld > /work/output/public-binary-after.sha256
cmp /work/output/public-binary-before.sha256 /work/output/public-binary-after.sha256
'''
(out/'commands.sh').write_text(script)
command=['docker','run','--rm','--name','recalld-coherent-rif-'+commit[:8],'--network','none','--cpus','2','--memory','4g','--memory-swap','4g','--cap-drop','ALL','--security-opt','no-new-privileges','--read-only','--tmpfs','/tmp:rw,nosuid,nodev','--mount',f'type=bind,src={root},dst=/work','--mount',f'type=bind,src={root}/source,dst=/work/source,readonly','--mount','type=bind,src=/tmp/recalld-canonical-harness-test-a1hpl2g2/cargo/registry,dst=/work/cargo/registry,readonly','-w','/work/source','-e','HOME=/tmp/home','-e','RUSTUP_TOOLCHAIN=1.94.1','-e','CARGO_HOME=/work/cargo','-e','CARGO_TARGET_DIR=/work/target','-e','CARGO_BUILD_JOBS=1','-e','CARGO_NET_OFFLINE=true','-e','PYTHONDONTWRITEBYTECODE=1',IMAGE,'sh','/work/output/commands.sh']
manifest={'sourceCommit':commit,'sourceTree':runner.git(SOURCE,'rev-parse','HEAD^{tree}').decode().strip(),'status':'running','command':command,'freshEmptyTarget':seed is None,'dependencySeed':str(seed) if seed else None,'packageCleanBeforeCompile':True,'harnessSha256':runner.sha(HARNESS),'driverSha256':runner.sha(Path(__file__))}
runner.save(out/'manifest.json',manifest)
Path('/tmp/recalld-rif-consumer-records/latest-root.txt').write_text(str(root)+'\n')
print(root,flush=True)
result=subprocess.run(command)
manifest['exitCode']=result.returncode
manifest['sourceUnchanged']=all(runner.sha(root/'source'/n)==h for n,h in prov['sourceFilesSha256'].items())
runner.save(out/'source-after.json',{n:runner.sha(root/'source'/n) for n in prov['sourceFilesSha256']})
manifest['status']='passed' if result.returncode==0 and manifest['sourceUnchanged'] else 'failed'
manifest['outputsSha256']={str(p.relative_to(out)):runner.sha(p) for p in out.rglob('*') if p.is_file() and p.name!='manifest.json'}
runner.save(out/'manifest.json',manifest)
print(json.dumps({'root':str(root),'status':manifest['status'],'exitCode':result.returncode}),flush=True)
sys.exit(result.returncode)
