set -eu
mkdir -p /tmp/home
trap 'cat /sys/fs/cgroup/memory.events > /work/output/memory-events.txt; cat /sys/fs/cgroup/memory.peak > /work/output/memory-peak.txt' EXIT
rustc -Vv > /work/output/rustc.txt
cat /sys/fs/cgroup/cpu.max > /work/output/cgroup-cpu.txt
cat /sys/fs/cgroup/memory.max > /work/output/cgroup-memory.txt
cargo fmt --all --check > /work/output/fmt.log 2>&1
cargo clean -p recalld > /work/output/package-clean.log 2>&1
cargo test --offline --locked --all-features --lib --bins --tests --examples --no-run -j1 > /work/output/compile.log 2>&1
python3 /work/output/binary-hashes.py > /work/output/test-binaries-before.json
cargo test --offline --locked --all-features --lib rif_ -j1 > /work/output/focused-rif.log 2>&1
cargo test --offline --locked --all-features --lib coherent_payload_ -j1 > /work/output/focused-payload.log 2>&1
cargo test --offline --locked --all-features --lib --bins --tests --examples -j1 > /work/output/full-suite.log 2>&1
python3 /work/output/binary-hashes.py > /work/output/test-binaries-after.json
cmp /work/output/test-binaries-before.json /work/output/test-binaries-after.json
cargo clippy --offline --locked --all-features --all-targets -j1 > /work/output/clippy.log 2>&1
python3 scripts/test_public_conformance.py > /work/output/runner-tests.log 2>&1
cargo build --offline --locked --bin recalld -j1 > /work/output/build.log 2>&1
sha256sum /work/target/debug/recalld > /work/output/public-binary-before.sha256
python3 scripts/public-conformance.py --inside --fixture-version 3 > /work/output/public-runner.log 2>&1
sha256sum /work/target/debug/recalld > /work/output/public-binary-after.sha256
cmp /work/output/public-binary-before.sha256 /work/output/public-binary-after.sha256
