import hashlib,json,subprocess,sys,time
from pathlib import Path
root=Path('/tmp/recalld-owned-native-ids-focused-iuexejqf'); prior=root/'output';out=root/'full-output-final';out.mkdir()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
d=json.loads((prior/'manifest.json').read_text());assert d['status']=='passed'
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==d['sourceCommit']
for rel,digest in d['sourceFilesSha256'].items():
 assert sha(root/'source'/rel)==digest,rel
 current=Path(rel)
 if current.is_file():assert sha(current)==digest,rel
 else:
  assert rel in ('benchmarks/public-conformance/fixture-v2.json','benchmarks/public-conformance/fixture-v3.json','benchmarks/public-conformance/fixture.json','scripts/public-conformance.Dockerfile','scripts/public-conformance.py','scripts/test_public_conformance.py'),rel
  assert sha(Path('/tmp/recalld-implementation/observed-consumer-evidence')/rel)==digest,rel
script='''set -eu
trap 'cat /sys/fs/cgroup/memory.events > /work/full-output/memory-events.txt; cat /sys/fs/cgroup/memory.peak > /work/full-output/memory-peak.txt' EXIT
cargo fmt --all --check > /work/full-output/fmt.log 2>&1
cargo test --offline --locked --all-features --lib --bins --tests --examples -j 1 > /work/full-output/full-suite.log 2>&1
cargo clippy --offline --locked --all-features --all-targets -j 1 > /work/full-output/clippy.log 2>&1
cargo build --offline --locked --bin recalld -j 1 > /work/full-output/bin-build.log 2>&1
python3 scripts/public-conformance.py --inside --fixture-version 3 > /work/full-output/public.log 2>&1
python3 scripts/test_public_conformance.py > /work/full-output/runner-tests.log 2>&1
'''
cmd=d['command'][:-3]+[d['imageId'],'sh','-c',script]
# Original command tail is IMAGE, sh, -c, SCRIPT.
cmd=d['command'][:-4]+[d['imageId'],'sh','-c',script]
(out/'driver.py').write_bytes(Path(__file__).read_bytes())
m={**d,'command':cmd,'mode':'full-existing-identical-source','status':'running','priorManifestSha256':sha(prior/'manifest.json'),'driverSha256':sha(Path(__file__)),'startedUnix':time.time()}
(out/'manifest.json').write_text(json.dumps(m,indent=2)+'\n');print(out,flush=True)
p=subprocess.run(cmd)
for rel,digest in d['sourceFilesSha256'].items():assert sha(root/'source'/rel)==digest,rel
m.update(status='passed' if p.returncode==0 else 'failed',exitCode=p.returncode,finishedUnix=time.time())
m['outputsSha256']={str(f.relative_to(out)):sha(f) for f in out.rglob('*') if f.is_file() and f.name!='manifest.json' and 'data' not in f.parts}
(out/'manifest.json').write_text(json.dumps(m,indent=2)+'\n');print(m['status'],flush=True);sys.exit(p.returncode)
