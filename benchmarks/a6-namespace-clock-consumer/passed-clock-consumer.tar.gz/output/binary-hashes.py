import hashlib,json,os,sys
from pathlib import Path
r=Path('/work/target/debug')
files=[p for p in r.rglob('*') if p.is_file() and os.access(p,os.X_OK) and ((p.parent==r or p.parent==r/'deps') and p.name.startswith(('recalld','lifecycle_cli-','text_migration_cli-')) or p.parent==r/'examples')]
print(json.dumps({str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(files)},indent=2))
