set -eu
mkdir -p /tmp/home
trap 'cat /sys/fs/cgroup/memory.events > /work/output/memory-events.txt; cat /sys/fs/cgroup/memory.peak > /work/output/memory-peak.txt' EXIT
rustc -Vv > /work/output/rustc.txt
cat /sys/fs/cgroup/cpu.max > /work/output/cgroup-cpu.txt
cat /sys/fs/cgroup/memory.max > /work/output/cgroup-memory.txt
cargo fmt --all --check > /work/output/fmt.log 2>&1
cargo clean -p recalld > /work/output/package-clean.log 2>&1
cargo test --offline --locked --all-features --lib --bins --tests --examples --no-run -j1 > /work/output/compile.log 2>&1
python3 /work/output/binary-hashes.py > /work/output/test-binaries-before.json
python3 scripts/test_public_mcp_evaluation.py > /work/output/consumer-python.log 2>&1
cargo test --offline --locked --all-features --lib owned_namespace_clock_samples_once -j1 > /work/output/focused-namespace-clock.log 2>&1
cargo test --offline --locked --all-features --lib fts -j1 > /work/output/focused-fts.log 2>&1
cargo test --offline --locked --all-features --lib coherent_payload_ -j1 > /work/output/focused-payload.log 2>&1
cargo test --offline --locked --all-features --lib --bins --tests --examples -j1 > /work/output/full-suite.log 2>&1
python3 /work/output/binary-hashes.py > /work/output/test-binaries-after.json
cmp /work/output/test-binaries-before.json /work/output/test-binaries-after.json
cargo clippy --offline --locked --all-features --all-targets -j1 > /work/output/clippy.log 2>&1
python3 scripts/test_public_conformance.py > /work/output/runner-tests.log 2>&1
cargo build --offline --locked --bin recalld --features bench --example owned_evaluator --example score_mcp_episode -j1 > /work/output/build.log 2>&1
sha256sum /work/target/debug/recalld > /work/output/public-binary-before.sha256
python3 scripts/public-conformance.py --inside --fixture-version 3 > /work/output/public-runner.log 2>&1
sha256sum /work/target/debug/recalld > /work/output/public-binary-after.sha256
cmp /work/output/public-binary-before.sha256 /work/output/public-binary-after.sha256
sha256sum /work/target/debug/examples/owned_evaluator /work/target/debug/examples/score_mcp_episode > /work/output/consumer-binaries-before.sha256
python3 scripts/public-mcp-evaluation.py prepare --track serialized-owned-reset-synthetic-diagnostic-v1 --binary /work/target/debug/examples/owned_evaluator --scorer /work/target/debug/examples/score_mcp_episode --build /work/output/build.json --out /work/output/inputs > /work/output/prepare.log 2>&1
python3 scripts/public-mcp-evaluation.py run --binary /work/target/debug/examples/owned_evaluator --scorer /work/target/debug/examples/score_mcp_episode --source-root /work/source --manifest /work/output/inputs/manifest.json --out /work/output/episode-0 > /work/output/episode.log 2>&1
python3 scripts/test_reset_mcp_episode.py --source /work/source --inputs /work/output/inputs --baseline /work/output/episode-0 --binary /work/target/debug/examples/owned_evaluator --scorer /work/target/debug/examples/score_mcp_episode --out /work/output/canaries > /work/output/canaries.log 2>&1
python3 benchmarks/a6-reset-supervisor/pending-independent-startup-hash.py /work/output/episode-0 /work/output/canaries/changed-label-episode > /work/output/independent-startup-hash-gate.log 2>&1
sha256sum /work/target/debug/examples/owned_evaluator /work/target/debug/examples/score_mcp_episode > /work/output/consumer-binaries-after.sha256
cmp /work/output/consumer-binaries-before.sha256 /work/output/consumer-binaries-after.sha256
